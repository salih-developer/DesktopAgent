using System.Diagnostics;
using System.Text;

namespace DesktopAgent.Utils;

public static class ProcessRunner
{
    public static async Task<(bool Success, string Output, string? Error)> RunAsync(string command, CancellationToken ct = default)
    {
        var psi = new ProcessStartInfo
        {
            FileName = "cmd.exe",
            Arguments = "/c " + command,
            WorkingDirectory = WorkspaceContext.CurrentPath,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };

        var proc = new Process { StartInfo = psi, EnableRaisingEvents = true };
        var stdout = new StringBuilder();
        var stderr = new StringBuilder();

        proc.OutputDataReceived += (_, e) => { if (e.Data != null) stdout.AppendLine(e.Data); };
        proc.ErrorDataReceived += (_, e) => { if (e.Data != null) stderr.AppendLine(e.Data); };

        proc.Start();
        proc.BeginOutputReadLine();
        proc.BeginErrorReadLine();

        await Task.Run(() =>
        {
            while (!proc.HasExited)
            {
                if (ct.IsCancellationRequested)
                {
                    try { proc.Kill(); } catch { /* ignore */ }
                    break;
                }
                Thread.Sleep(50);
            }
        }, ct);

        var success = proc.ExitCode == 0;
        return (success, stdout.ToString().Trim(), stderr.Length > 0 ? stderr.ToString().Trim() : null);
    }
}
